# 로커스상상고딕(LocusSangsang)

<a href="https://wess.tistory.com" target="_blank">
    <img src="https://webfontworld.github.io/locus/LocusSangsang.jpg" alt="LocusSangsang" style="width:300px">
</a>

<pre>
@font-face {
    font-family: 'LocusSangsang';
    font-weight: normal;
    font-style: normal;
    src: url('https://cdn.jsdelivr.net/gh/webfontworld/locus/LocusSangsang.eot');
    src: url('https://cdn.jsdelivr.net/gh/webfontworld/locus/LocusSangsang.eot?#iefix') format('embedded-opentype'),
         url('https://cdn.jsdelivr.net/gh/webfontworld/locus/LocusSangsang.woff2') format('woff2'),
         url('https://cdn.jsdelivr.net/gh/webfontworld/locus/LocusSangsang.woff') format('woff'),
         url('https://cdn.jsdelivr.net/gh/webfontworld/locus/LocusSangsang.ttf') format("truetype");
    font-display: swap;
}
</pre>
